MapKluss Two-layer — experimental workflow

1. Import suppression.litematic and build only the two-layer art itself.
2. Open Two-layer in Companion and select this ZIP.
3. Hold a clean unlocked scale-0 map and select the support block below the art’s north-west edge.
4. Follow the highlights and manually hold the map only while standing on the marked point.
5. After final verification, lock the map with a glass pane.

Phases: 64
Blocks in the complete schematic: 32768
Recoverable after removal: 16384

Stand still during capture and do not open the map while travelling between points.
Companion does not lock inventory controls or equip the map for you.
MapKluss never places or breaks blocks automatically.
