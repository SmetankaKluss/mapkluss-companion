MapKluss Two-layer — large map art

Grid: 2×2 maps.
Parts in this archive: 4.

1. Open Two-layer in Companion and import this ZIP.
2. Choose a part. Numbering runs left to right, then top to bottom.
3. Companion installs the schematic and starts a separate session only for the selected map.
4. Hold a clean unlocked scale-0 map and follow the highlights.
5. After completion, stop the session and choose the next part from the same ZIP.

Companion does not lock inventory controls, equip maps for you, break blocks, or place blocks.
